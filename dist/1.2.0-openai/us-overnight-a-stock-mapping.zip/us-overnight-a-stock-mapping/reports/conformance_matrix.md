# Runtime Conformance Matrix

- Skill: `us-overnight-a-stock-mapping`
- Targets: `5`
- Passed: `3`
- Failed: `2`

| Target | Status | Failures | Warnings |
| --- | --- | --- | --- |
| openai | pass | None | None |
| claude | fail | manifest target missing: claude<br>adapter target missing: claude<br>Missing claude degradation note | None |
| agent-skills | pass | None | agent-skills uses canonical Agent Skills metadata; provider-native execution transforms are not implemented in v0. |
| vscode | pass | None | vscode uses canonical Agent Skills metadata; provider-native execution transforms are not implemented in v0. |
| generic | fail | manifest target missing: generic<br>adapter target missing: generic<br>Missing generic degradation note | None |

## Reviewer Notes

- Failed targets block release for that target.
- Warnings identify lossy or not-yet-compiled behavior that must remain visible.
