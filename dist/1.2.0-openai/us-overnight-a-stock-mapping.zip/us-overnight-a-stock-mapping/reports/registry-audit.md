# Registry Audit

- OK: `True`
- Package: `us-overnight-a-stock-mapping`
- Version: `1.2.0`
- Maturity: `production`
- Owner: `simplelove`
- License: `Copyright (c) 2026 simplelove. All rights reserved.`
- Package SHA256: `c90b3017e827b3eadc70ef52da433f9a7cb726e4e688d96b4e1928eee08893dd`
- Archive SHA256: `n/a`
- Install simulated: `False`

## Compatibility

| Target | Status |
| --- | --- |
| `openai` | `pass` |
| `claude` | `fail` |
| `agent-skills` | `pass` |
| `vscode` | `pass` |
| `generic` | `fail` |
| `agent-skills-compatible` | `pass` |

## Failures

- None

## Warnings

- Recommended registry evidence is missing: reports/skill-overview.html
- Recommended registry evidence is missing: reports/review-studio.html
- Recommended registry evidence is missing: reports/compiled_targets.md
- Recommended registry evidence is missing: reports/review_waivers.md
- Recommended registry evidence is missing: reports/review_annotations.md

## Artifacts

- index: `C:\Users\simplelove\.codex\skills\us-overnight-a-stock-mapping\registry\index.json`
- package: `C:\Users\simplelove\.codex\skills\us-overnight-a-stock-mapping\registry\packages\us-overnight-a-stock-mapping.json`
- json: `C:\Users\simplelove\.codex\skills\us-overnight-a-stock-mapping\reports\registry-audit.json`
- markdown: `C:\Users\simplelove\.codex\skills\us-overnight-a-stock-mapping\reports\registry-audit.md`
