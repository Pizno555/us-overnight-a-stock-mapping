# 源设计追踪与版本说明

## input_files

- `references/source-design-v1.0.md`：`file-backed fixture`，来自用户提供的 `us-overnight-a-stock-mapping-v1.0.md`。
- 原文件SHA-256：`A8B9389D8AC5648D0EC14039BF83A84354FE8EED72219402850A3D5780061D88`。
- 原文件共2765行；复制件保持字节级一致，用于审计，不作为每次执行时必须全量加载的入口上下文。

## 版本说明

- 源设计标题和头部版本字段为 `v1.0`。
- 源设计末尾包含“v1.3相对v1.2”的四项修正说明，但未同步修改标题。
- 本包把源规范标记为“v1.0（含末尾v1.3修正规则）”，并把本次工程修订版本设为 `1.2.0`；不擅自把源文件改称v1.3。

## 条款映射

| 源设计范围 | 落地文件 |
|---|---|
| 0–18：目标、双雷达、归因、催化、产业链、L级 | `SKILL.md`、`radars-and-attribution.md` |
| 19–24：Candidate、Shortlist、10步法、E/P/Evidence、同行与反证 | `a-share-validation.md` |
| 25–31：三套排名、多维向量、T_static、竞价和三类池 | `trading-and-pools.md` |
| 32–38：每日输出、摘要和产业模板 | `output-spec.md` |
| 39–44：防漏、防错、禁止项、决策树和最终原则 | `SKILL.md`及各参考文件终检规则 |
| 工程补强：近邻路由 | `routing-and-handoffs.md`、`evals/trigger_cases.json` |
| 工程补强：数据与指标口径 | `data-and-metrics-contract.md`、`scripts/compute_indicators.py` |
| 工程补强：扫描覆盖分母 | `radar-scan-coverage-contract.md`、`evals/output/cases.jsonl` |
| 工程补强：真实历史回放 | `evals/replay/`、`reports/runtime-replay-summary.md` |

## output contract

完整运行输出编号0–17的18个模块，并包含数据截止、coverage_log、双雷达、未归因信号、背离、A股初筛/深验、多维向量、产业/交易双排序、Auction Conditions、Core/Watch/Exclude及推翻条件。窄请求可只输出相关模块，但不得跳过它依赖的上游验证。

## rollback boundary

回滚仅限本Skill目录。不得修改、删除或覆盖 `a-stock-trading-review`、`a-stock-evidence-research`、`a-stock-investment-analysis`、`serenity-skill`，不得更改用户行情文件或Codex全局配置。回滚1.2.0时仅撤销扫描覆盖契约、真实回放评测及对应追踪/报告更新；回滚1.1.0时再删除新增的路由、数据契约、脚本、评测、报告和治理文件，并恢复1.0入口及UI文件。

## 变更记录

- `1.0.0`：依据源设计生成的首版个人Skill。
- `1.1.0`：收紧海外隔夜锚点路由；新增四个近邻Skill交接；定义时间、覆盖和指标口径；增加确定性指标脚本、触发/输出评测、Skill IR和Production治理元数据；统一18模块和中文UI。
- `1.2.0`：新增可审计的Radar Scan Coverage Contract；无Universe和分母时禁止标记covered；加入5个真实历史交互式回放并与provider-runner证据分开；修复源设计副本的字节级一致性；补充Windows UTF-8验证复现说明。
