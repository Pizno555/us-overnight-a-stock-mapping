# Registry Audit

- OK: `True`
- Package: `us-overnight-a-stock-mapping`
- Version: `1.2.1`
- Maturity: `production`
- Owner: `simplelove`
- License: `Copyright (c) 2026 simplelove. All rights reserved.`
- Package SHA256: `c5a38ab572eccb979585419e920e2fd9aed784d8298a8ea42697010d790e0f4d`
- Archive SHA256: `92b5a30be5538b472f62933bee1a43b5c7c044f52f765907dd151ea01da63c13`
- Install simulated: `True`

## Compatibility

| Target | Status |
| --- | --- |
| `openai` | `pass` |

## Failures

- None

## Warnings

- Recommended registry evidence is missing: reports/compiled_targets.md
- Recommended registry evidence is missing: reports/review_waivers.md
- Recommended registry evidence is missing: reports/review_annotations.md

## Artifacts

- index: `C:\Users\simplelove\.codex\skills\us-overnight-a-stock-mapping\registry\index.json`
- package: `C:\Users\simplelove\.codex\skills\us-overnight-a-stock-mapping\registry\packages\us-overnight-a-stock-mapping.json`
- json: `C:\Users\simplelove\.codex\skills\us-overnight-a-stock-mapping\reports\registry-audit.json`
- markdown: `C:\Users\simplelove\.codex\skills\us-overnight-a-stock-mapping\reports\registry-audit.md`
